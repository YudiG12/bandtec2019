package Filme;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Teste {

    private static Scanner scanner = new Scanner(System.in);

    public static void gravarArquivo(ListaObj<Filme> lista, boolean isCSV) {
        FileWriter arq = null;
        Formatter saida = null;
        boolean falhou = false;
        String nomeArquivo;

        if (isCSV) {
            nomeArquivo= "filme.csv";
        }
        else {
            nomeArquivo= "filme.txt";
        }

        try {
            arq = new FileWriter(nomeArquivo, true);
            saida = new Formatter(arq);
        }
        catch (IOException erro) {
            System.err.println("Erro ao abrir arquivo.");
            System.exit(1);
        }

        try {
            for (int i=0; i < lista.getTamanho(); i++) {
                Filme filme = lista.getElemento(i);
                if (isCSV) {
                    saida.format("%d;%s;%.2f;%s;%d%n",filme.getIdFilme(),filme.getNome(),
                            filme.getNota(),filme.getGenero(),filme.getIdade());
                }
                else {
                    saida.format("%d %s %.2f %s %d%n",filme.getIdFilme(),filme.getNome(),
                            filme.getNota(),filme.getGenero(),filme.getIdade());
                }
            }
        }
        catch (FormatterClosedException erro )
        {
            System.err.println("Erro ao gravar no arquivo.");
            falhou = true;
        }
        finally {
            saida.close();
            try {
                arq.close();
            }
            catch (IOException erro) {
                System.err.println("Erro ao fechar arquivo.");
                falhou = true;
            }
            if (falhou) {
                System.exit(1);
            }
        }
    }

    public static void gravarArquivoGenero(ListaObj<Filme> lista, boolean isCSV, String genero) {
        FileWriter arq = null;
        Formatter saida = null;
        boolean falhou = false;
        String nomeArquivo;

        if (isCSV) {
            nomeArquivo= genero+".csv";
        }
        else {
            nomeArquivo= genero+".txt";
        }

        try {
            arq = new FileWriter(nomeArquivo, true);
            saida = new Formatter(arq);
        }
        catch (IOException erro) {
            System.err.println("Erro ao abrir arquivo.");
            System.exit(1);
        }

        try {
            for (int i=0; i < lista.getTamanho(); i++) {
                Filme filme = lista.getElemento(i);;
                if (filme.getGenero().equals(genero)) {
                    if (isCSV) {
                        saida.format("%d;%s;%.2f;%s;%d%n", filme.getIdFilme(), filme.getNome(),
                                filme.getNota(), filme.getGenero(), filme.getIdade());
                    } else {
                        saida.format("%d %s %.2f %s %d%n", filme.getIdFilme(), filme.getNome(),
                                filme.getNota(), filme.getGenero(), filme.getIdade());
                    }
                }
            }
        }
        catch (FormatterClosedException erro )
        {
            System.err.println("Erro ao gravar no arquivo.");
            falhou = true;
        }
        finally {
            saida.close();
            try {
                arq.close();
            }
            catch (IOException erro) {
                System.err.println("Erro ao fechar arquivo.");
                falhou = true;
            }
            if (falhou) {
                System.exit(1);
            }
        }
    }

    public static void lerEExibirArquivo(boolean isCSV) {
        FileReader arq = null;
        Scanner entrada = null;
        String nomeArquivo;
        boolean falhou = false;

        if (isCSV) {
            nomeArquivo= "filme.csv";
        }
        else {
            nomeArquivo= "filme.txt";
        }

        try {
            arq = new FileReader(nomeArquivo);
            if (isCSV) {
                entrada = new Scanner(arq).useDelimiter(";|\\r\\n");
            }
            else {
                entrada = new Scanner(arq);
            }
        }
        catch (FileNotFoundException erro) {
            System.err.println("Arquivo não encontrado");
            System.exit(1);
        }

        try {
            System.out.printf("%-10s%-10s%-7s%-10s%-5s\n","ID","NOME","NOTA","GÊNERO","IDADE");
            while (entrada.hasNext()) {
                int idFilme = entrada.nextInt();
                String nome = entrada.next();
                double nota = entrada.nextDouble();
                String genero = entrada.next();
                int idade = entrada.nextInt();
                System.out.printf("%-10d%-10s%-7.2f%-10s%-5d\n",idFilme,nome,nota,genero,idade);
            }
        }
        catch (NoSuchElementException erro)
        {
            System.err.println("Arquivo com problemas.");
            falhou = true;
        }
        catch (IllegalStateException erro)
        {
            System.err.println("Erro na leitura do arquivo.");
            falhou = true;
        }
        finally {
            entrada.close();
            try {
                arq.close();
            }
            catch (IOException erro) {
                System.err.println("Erro ao fechar arquivo.");
                falhou = true;
            }
            if (falhou) {
                System.exit(1);
            }
        }
    }

    public static ListaObj lerEArmazenar(boolean isCSV,String genero) {
        FileReader arq = null;
        Scanner entrada = null;
        String nomeArquivo;
        boolean falhou = false;

        if (isCSV) {
            nomeArquivo= genero+".csv";
        }
        else {
            nomeArquivo= genero+".txt";
        }

        try {
            arq = new FileReader(nomeArquivo);
            if (isCSV) {
                entrada = new Scanner(arq).useDelimiter(";|\\r\\n");
            }
            else {
                entrada = new Scanner(arq);
            }
        }
        catch (FileNotFoundException erro) {
            System.err.println("Arquivo não encontrado");
            System.exit(1);
        }
        ListaObj<Filme> lista = new ListaObj<Filme>(5);
        try {
            while (entrada.hasNext()) {
                int idFilme = entrada.nextInt();
                String nome = entrada.next();
                double nota = entrada.nextDouble();
                String filmeGenero = entrada.next();
                int idade = entrada.nextInt();
                lista.adiciona(new Filme(idFilme,nome,nota,filmeGenero,idade));
            }
        }
        catch (NoSuchElementException erro)
        {
            System.err.println("Arquivo com problemas.");
            falhou = true;
        }
        catch (IllegalStateException erro)
        {
            System.err.println("Erro na leitura do arquivo.");
            falhou = true;
        }
        finally {
            entrada.close();
            try {
                arq.close();
            }
            catch (IOException erro) {
                System.err.println("Erro ao fechar arquivo.");
                falhou = true;
            }
            if (falhou) {
                System.exit(1);
            }
        }
        return lista;
    }

    public static void main(String[] args) {
        int idFilme;
        String nome;
        double nota;
        String genero;
        int idade;

        ListaObj<Filme> lista = new ListaObj<Filme>(5);

        boolean continuar = true;
        while(continuar) {


            System.out.println("\nEscolha uma das opções a seguir:");
            System.out.println("1- Adicionar um filme");
            System.out.println("2- Exibir a lista");
            System.out.println("3- Gravar a lista num arquivo txt");
            System.out.println("4- Ler e exibir arquivo txt");
            System.out.println("5- Gravar apenas filmes de um determinado genero em arquivo");
            System.out.println("6- Ler o arquivo e armazenar em lista");
            System.out.println("7- Sair");

            int opcao = scanner.nextInt();
            switch(opcao){

                case 1:  // adicionar filme
                    System.out.println("Digite o id do filme");
                    idFilme = scanner.nextInt();
                    System.out.println("Digite o nome do filme");
                    nome = scanner.next();
                    System.out.println("Digite a nota do filme");
                    nota = scanner.nextDouble();
                    System.out.println("Digite o gênero do filme");
                    genero = scanner.next();
                    System.out.println("Digite a idade mínima do filme");
                    idade = scanner.nextInt();

                    lista.adiciona(new Filme(idFilme, nome, nota, genero, idade));
                    break;

                case 2: // exibir lista
                    lista.exibe();
                    break;
                case 3: // gravar lista em arquivo
                    if (lista.getTamanho() == 0) {
                        System.out.println("Lista está vazia. Não há nada a gravar");
                    }
                    else {
                        gravarArquivo(lista, false);
                        lista.limpa();
                    }
                    break;
                case 4: // ler e exibir o arquivo
                    lerEExibirArquivo(false);
                    break;
                case 5: // gravar apenas filmes de um determinado genero em arquivo
                    if (lista.getTamanho() == 0) {
                        System.out.println("Lista está vazia. Não há nada a gravar");
                    }
                    else {
                        System.out.println("Informe o nome de um gênero");
                        String generoSeparado = scanner.next();
                        gravarArquivoGenero(lista, false, generoSeparado);
                        lista.limpa();
                    }
                    break;
                case 6: // ler o arquivo e armazenar em lista
                    ListaObj<Filme> lista2 = new ListaObj<Filme>(5);
                    System.out.println("Informe o nome de um gênero");
                    String generoSeparado = scanner.next();
                    lista2 = lerEArmazenar(false,generoSeparado);
                    lista2.exibe();
                    break;
                case 7: // sair
                    System.out.println("Saindo...");
                    continuar = false;
                    break;
                default:
                    System.out.println("opção inválida!");
                    break;
            }
        }
    }

}
